from flask import Flask
from flask_sqlalchemy import SQLAlchemy

# Initialize SQLAlchemy globally, but link it later inside the factory function
db = SQLAlchemy()

def create_app():
    app = Flask(__name__)
    
    # Configuration Settings
    app.config['SECRET_KEY'] = 'your_secret_key_here'
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///todo.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    # Link the database instance with the Flask App
    db.init_app(app)
    
    # Import and register Blueprints to decouple roots logic
    from app.roots.auth import auth_bp
    from app.roots.tasks import task_bp
    
    app.register_blueprint(auth_bp)
    app.register_blueprint(task_bp)
    
    return app

