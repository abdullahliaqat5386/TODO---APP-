from app import create_app, db
from app.models import Task

# Instantiate the final configurations
app = create_app()

# Explicitly open an application context to verify and construct the SQL tables
with app.app_context():
    db.create_all()

if __name__ == '__main__':
    # Execute structural debugging and spin up the local development web server
    app.run(debug=True)